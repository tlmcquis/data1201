# Questions for Lab 10!

### Question 1: What happens when you swap the delimiter from commas to tabs? How does the preview change? 
(Make sure "disable live preview is not checked if you don't see a change)

### Question 2: Try sorting the scientificName facet by name and by count. What problems are there with the data?

### Question 3: Use faceting to figure out the following:
#### How many different years are represented in this file?
#### What year occurs the most times?
#### What year occurs the least number of times?

### Question 4: What happens when you make a numerical facet of column note1, then convert the column to numbers? Is something different about the facet compared to yr?

### Question 5: Click and drag on the scatterplot facet you made to highlight a rectangle. What happens to the data points being displayed?

# Questions for Post-Lab Assignment 10!

### Question 6: After the last step, some columns are empty. (You can check by text faceting a column) Why? What do you think we can do to fix it?
